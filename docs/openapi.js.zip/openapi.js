/**
 * OpenAPI 3.0 spec for the VNP <> Airwallex API.
 * Keep this in sync with the routes/controllers as new endpoints are added.
 */
module.exports = {
    openapi: '3.0.3',
    info: {
        title: 'VNP <> AIRWALLEX API',
        version: '0.1.0',
        description: 'API for the VNP <> Airwallex integration app.',
    },
    servers: [{ url: '/api', description: 'Current host' }],
    tags: [
        { name: 'Auth', description: 'Authentication endpoints' },
        { name: 'Users', description: 'User management endpoints' },
        { name: 'Payments', description: 'Airwallex payments and local payment history' },
    ],
    components: {
        securitySchemes: {
            bearerAuth: {
                type: 'http',
                scheme: 'bearer',
                bearerFormat: 'JWT',
            },
        },
        schemas: {
            User: {
                type: 'object',
                properties: {
                    _id: { type: 'string', example: '66501a3f5d2c8e0012abcd34' },
                    email: { type: 'string', format: 'email', example: 'jane@example.com' },
                    first_name: { type: 'string', example: 'Jane' },
                    last_name: { type: 'string', example: 'Doe' },
                    status: {
                        type: 'string',
                        enum: ['active', 'pending', 'revoked'],
                        example: 'active',
                    },
                    invited_by: { type: 'string', nullable: true },
                    invite_accepted_at: { type: 'string', format: 'date-time', nullable: true },
                    created_at: { type: 'string', format: 'date-time' },
                    updated_at: { type: 'string', format: 'date-time' },
                },
            },
            Payment: {
                type: 'object',
                description:
                    'Local mirror of an Airwallex Payment Intent. Airwallex owns status and captured_amount; everything else is ours.',
                properties: {
                    _id: { type: 'string' },
                    payment_intent_id: { type: 'string', example: 'int_sgpvlj8cshln5x35ae5' },
                    merchant_order_id: { type: 'string', example: 'vnp_1787577831000_a1b2c3d4' },
                    request_id: { type: 'string', format: 'uuid' },
                    amount: { type: 'number', example: 12.5 },
                    currency: { type: 'string', example: 'USD' },
                    captured_amount: { type: 'number', example: 0 },
                    descriptor: {
                        type: 'string',
                        maxLength: 32,
                        description: 'Dynamic statement descriptor shown on the card statement.',
                        example: 'VNP*BK-10482',
                    },
                    status: {
                        type: 'string',
                        enum: [
                            'REQUIRES_PAYMENT_METHOD',
                            'REQUIRES_CUSTOMER_ACTION',
                            'REQUIRES_CAPTURE',
                            'PENDING',
                            'SUCCEEDED',
                            'CANCELLED',
                            'EXPIRED',
                            'FAILED',
                        ],
                    },
                    checkout_mode: {
                        type: 'string',
                        enum: ['hosted_page', 'embedded_elements'],
                    },
                    reference: { type: 'string' },
                    description: { type: 'string' },
                    customer: {
                        type: 'object',
                        properties: {
                            name: { type: 'string' },
                            email: { type: 'string', format: 'email' },
                            phone: { type: 'string' },
                        },
                    },
                    payment_method_type: { type: 'string', example: 'card' },
                    card_brand: { type: 'string', example: 'visa' },
                    card_last4: { type: 'string', example: '4242' },
                    events: {
                        type: 'array',
                        description: 'Local audit trail, newest last.',
                        items: {
                            type: 'object',
                            properties: {
                                name: { type: 'string', example: 'payment_intent.succeeded' },
                                status: { type: 'string' },
                                source: { type: 'string', enum: ['webhook', 'sync', 'local'] },
                                occurred_at: { type: 'string', format: 'date-time' },
                                event_id: { type: 'string' },
                            },
                        },
                    },
                    last_synced_at: { type: 'string', format: 'date-time' },
                    created_at: { type: 'string', format: 'date-time' },
                    updated_at: { type: 'string', format: 'date-time' },
                },
            },
            CheckoutHandoff: {
                type: 'object',
                description:
                    'Everything the browser needs to open checkout. client_secret is short-lived and is never persisted server-side.',
                properties: {
                    intent_id: { type: 'string' },
                    client_secret: { type: 'string' },
                    currency: { type: 'string' },
                    amount: { type: 'number' },
                    env: { type: 'string', enum: ['demo', 'prod'] },
                    mode: { type: 'string', enum: ['hosted_page', 'embedded_elements'] },
                    successUrl: { type: 'string', format: 'uri' },
                    cancelUrl: { type: 'string', format: 'uri' },
                },
            },
            Error: {
                type: 'object',
                properties: { error: { type: 'string' } },
            },
        },
        responses: {
            Unauthorized: {
                description: 'Missing, invalid or expired token',
                content: {
                    'application/json': {
                        schema: { $ref: '#/components/schemas/Error' },
                    },
                },
            },
            BadRequest: {
                description: 'Validation error',
                content: {
                    'application/json': {
                        schema: { $ref: '#/components/schemas/Error' },
                    },
                },
            },
        },
    },
    paths: {
        '/auth/login': {
            post: {
                tags: ['Auth'],
                summary: 'Step 1 — email + password, emails a 6-digit OTP',
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['email', 'password'],
                                properties: {
                                    email: { type: 'string', format: 'email' },
                                    password: { type: 'string', format: 'password' },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: {
                        description: 'OTP sent',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        message: { type: 'string' },
                                        email: { type: 'string' },
                                        expires_at: { type: 'string', format: 'date-time' },
                                    },
                                },
                            },
                        },
                    },
                    400: { $ref: '#/components/responses/BadRequest' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/auth/verify': {
            post: {
                tags: ['Auth'],
                summary: 'Step 2 — verify the OTP and receive a JWT',
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['email', 'otp'],
                                properties: {
                                    email: { type: 'string', format: 'email' },
                                    otp: { type: 'string', example: '048213' },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: {
                        description: 'Authenticated',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        userId: { type: 'string' },
                                        token: { type: 'string' },
                                        first_name: { type: 'string' },
                                        last_name: { type: 'string' },
                                        email: { type: 'string' },
                                    },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/auth/forgot-password': {
            post: {
                tags: ['Auth'],
                summary: 'Request a password reset code',
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['email'],
                                properties: { email: { type: 'string', format: 'email' } },
                            },
                        },
                    },
                },
                responses: {
                    200: { description: 'Reset code sent (if the account exists)' },
                    400: { $ref: '#/components/responses/BadRequest' },
                },
            },
        },
        '/auth/forgot-password/verify': {
            post: {
                tags: ['Auth'],
                summary: 'Verify a reset code and receive a short-lived reset token',
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['email', 'otp'],
                                properties: {
                                    email: { type: 'string', format: 'email' },
                                    otp: { type: 'string' },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: {
                        description: 'Reset token issued',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: { reset_token: { type: 'string' } },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/auth/forgot-password/reset': {
            post: {
                tags: ['Auth'],
                summary: 'Set a new password using a reset token',
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['reset_token', 'new_password'],
                                properties: {
                                    reset_token: { type: 'string' },
                                    new_password: { type: 'string', minLength: 8 },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: { description: 'Password updated' },
                    400: { $ref: '#/components/responses/BadRequest' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/payments': {
            get: {
                tags: ['Payments'],
                summary: 'List local payment history',
                security: [{ bearerAuth: [] }],
                parameters: [
                    {
                        name: 'q',
                        in: 'query',
                        description: 'Matches intent id, order id, reference, description, descriptor or customer.',
                        schema: { type: 'string' },
                    },
                    { name: 'status', in: 'query', schema: { type: 'string', example: 'SUCCEEDED' } },
                    {
                        name: 'checkout_mode',
                        in: 'query',
                        schema: { type: 'string', enum: ['hosted_page', 'embedded_elements'] },
                    },
                    { name: 'sort', in: 'query', schema: { type: 'string', enum: ['asc', 'desc'], default: 'desc' } },
                    { name: 'limit', in: 'query', schema: { type: 'integer', default: 25, maximum: 100 } },
                    { name: 'skip', in: 'query', schema: { type: 'integer', default: 0 } },
                ],
                responses: {
                    200: {
                        description: 'Paged payment history',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        items: { type: 'array', items: { $ref: '#/components/schemas/Payment' } },
                                        total: { type: 'integer' },
                                        limit: { type: 'integer' },
                                        skip: { type: 'integer' },
                                    },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
            post: {
                tags: ['Payments'],
                summary: 'Create a Payment Intent and open checkout',
                description:
                    'Creates the intent at Airwallex, mirrors it locally, and returns everything the browser needs to launch either the Hosted Payment Page or the embedded drop-in element.',
                security: [{ bearerAuth: [] }],
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['amount', 'currency'],
                                properties: {
                                    amount: { type: 'number', example: 12.5 },
                                    currency: { type: 'string', example: 'USD' },
                                    reference: {
                                        type: 'string',
                                        description: 'Order reference; feeds the dynamic descriptor.',
                                        example: 'BK-10482',
                                    },
                                    description: { type: 'string', example: 'Hotel booking - 3 nights' },
                                    descriptor: {
                                        type: 'string',
                                        maxLength: 32,
                                        description:
                                            'Explicit statement descriptor. Omit to auto-build one from descriptor_prefix + reference.',
                                    },
                                    descriptor_prefix: {
                                        type: 'string',
                                        description: 'Overrides AIRWALLEX_DESCRIPTOR_PREFIX for this payment.',
                                    },
                                    checkout_mode: {
                                        type: 'string',
                                        enum: ['hosted_page', 'embedded_elements'],
                                        default: 'hosted_page',
                                    },
                                    customer: {
                                        type: 'object',
                                        properties: {
                                            name: { type: 'string' },
                                            email: { type: 'string', format: 'email' },
                                            phone: { type: 'string' },
                                        },
                                    },
                                    metadata: { type: 'object', additionalProperties: true },
                                },
                            },
                        },
                    },
                },
                responses: {
                    201: {
                        description: 'Intent created',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        payment: { $ref: '#/components/schemas/Payment' },
                                        checkout: { $ref: '#/components/schemas/CheckoutHandoff' },
                                    },
                                },
                            },
                        },
                    },
                    400: { $ref: '#/components/responses/BadRequest' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    502: { description: 'Airwallex rejected or could not be reached' },
                },
            },
        },
        '/payments/query': {
            post: {
                tags: ['Payments'],
                summary: 'Filtered, sorted, paged payment history',
                description:
                    'Global filters: conditions are applied in Mongo so they span the whole history, not just the loaded page. Unknown fields are ignored rather than passed through.',
                security: [{ bearerAuth: [] }],
                requestBody: {
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                properties: {
                                    filters: {
                                        type: 'object',
                                        description:
                                            'Map of field -> condition. text/enum accept {op:in|contains|startswith|endswith|eq}; number accepts {op:eq|ne|gt|gte|lt|lte|between}; date accepts {after, before}.',
                                        example: {
                                            status: { op: 'in', value: ['SUCCEEDED'] },
                                            amount: { op: 'between', min: 10, max: 500 },
                                            created_at: { after: '2026-08-01' },
                                        },
                                    },
                                    sort: {
                                        type: 'object',
                                        properties: {
                                            key: { type: 'string', example: 'amount' },
                                            dir: { type: 'string', enum: ['asc', 'desc'] },
                                        },
                                    },
                                    search: { type: 'string' },
                                    limit: { type: 'integer', default: 25, maximum: 100 },
                                    skip: { type: 'integer', default: 0 },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: {
                        description: 'Matching payments plus totals for the whole filtered set',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        items: {
                                            type: 'array',
                                            items: { $ref: '#/components/schemas/Payment' },
                                        },
                                        total: { type: 'integer' },
                                        limit: { type: 'integer' },
                                        skip: { type: 'integer' },
                                        totals: {
                                            type: 'array',
                                            description: 'Summed amounts per currency across every matching row.',
                                            items: {
                                                type: 'object',
                                                properties: {
                                                    currency: { type: 'string' },
                                                    amount: { type: 'number' },
                                                    captured: { type: 'number' },
                                                    count: { type: 'integer' },
                                                },
                                            },
                                        },
                                    },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/payments/distinct/{field}': {
            get: {
                tags: ['Payments'],
                summary: 'Distinct values for a filterable field',
                description:
                    'Populates the checkbox list in the column filter popover. Fields outside the filterable allow-list are rejected.',
                security: [{ bearerAuth: [] }],
                parameters: [
                    {
                        name: 'field',
                        in: 'path',
                        required: true,
                        schema: { type: 'string', example: 'status' },
                    },
                    { name: 'search', in: 'query', schema: { type: 'string' } },
                    { name: 'limit', in: 'query', schema: { type: 'integer', default: 200, maximum: 500 } },
                ],
                responses: {
                    200: {
                        description: 'Distinct values',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        values: { type: 'array', items: { type: 'string' } },
                                        total: { type: 'integer' },
                                        shown: { type: 'integer' },
                                    },
                                },
                            },
                        },
                    },
                    400: { description: 'Field is not filterable' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/payments/analytics': {
            get: {
                tags: ['Payments'],
                summary: 'Chart data for the dashboard',
                security: [{ bearerAuth: [] }],
                parameters: [
                    {
                        name: 'period',
                        in: 'query',
                        schema: { type: 'string', enum: ['all', 'year', 'month', 'week'], default: 'all' },
                    },
                ],
                responses: {
                    200: {
                        description: 'Daily series plus donut breakdowns',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        period: { type: 'string' },
                                        daily_amounts: {
                                            type: 'array',
                                            description:
                                                'One row per day: { date, <STATUS>: amount, ... } — only statuses present in the period appear.',
                                            items: { type: 'object', additionalProperties: true },
                                        },
                                        by_checkout_mode: {
                                            type: 'object',
                                            additionalProperties: { type: 'integer' },
                                        },
                                        by_status: {
                                            type: 'object',
                                            additionalProperties: { type: 'integer' },
                                        },
                                        by_currency: {
                                            type: 'array',
                                            items: {
                                                type: 'object',
                                                properties: {
                                                    currency: { type: 'string' },
                                                    count: { type: 'integer' },
                                                    amount: { type: 'number' },
                                                },
                                            },
                                        },
                                    },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/payments/stats': {
            get: {
                tags: ['Payments'],
                summary: 'Aggregate payment counts and captured totals',
                security: [{ bearerAuth: [] }],
                parameters: [
                    {
                        name: 'period',
                        in: 'query',
                        schema: { type: 'string', enum: ['all', 'year', 'month', 'week'], default: 'all' },
                    },
                ],
                responses: {
                    200: {
                        description: 'Totals by status and captured amount per currency',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        total: { type: 'integer' },
                                        succeeded: { type: 'integer' },
                                        by_status: { type: 'object', additionalProperties: { type: 'integer' } },
                                        captured: {
                                            type: 'array',
                                            items: {
                                                type: 'object',
                                                properties: {
                                                    currency: { type: 'string' },
                                                    amount: { type: 'number' },
                                                    count: { type: 'integer' },
                                                },
                                            },
                                        },
                                    },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
        },
        '/payments/status/{orderId}': {
            get: {
                tags: ['Payments'],
                summary: 'Public status lookup for the post-checkout return page',
                description:
                    'Unauthenticated: the shopper returning from checkout has no session. Re-reads the intent from Airwallex and returns only display fields.',
                parameters: [
                    { name: 'orderId', in: 'path', required: true, schema: { type: 'string' } },
                ],
                responses: {
                    200: {
                        description: 'Current payment status',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        merchant_order_id: { type: 'string' },
                                        status: { type: 'string' },
                                        amount: { type: 'number' },
                                        currency: { type: 'string' },
                                        captured_amount: { type: 'number' },
                                        descriptor: { type: 'string' },
                                        reference: { type: 'string' },
                                        description: { type: 'string' },
                                    },
                                },
                            },
                        },
                    },
                    404: { description: 'Not found' },
                },
            },
        },
        '/payments/webhook': {
            post: {
                tags: ['Payments'],
                summary: 'Airwallex webhook receiver',
                description:
                    'Authenticated by HMAC-SHA256 over `x-timestamp + raw body` using AIRWALLEX_WEBHOOK_SECRET, not by JWT. payment_intent.* events update status directly; payment_attempt.* and refund.* events trigger a re-read of the intent.',
                parameters: [
                    { name: 'x-timestamp', in: 'header', required: true, schema: { type: 'string' } },
                    { name: 'x-signature', in: 'header', required: true, schema: { type: 'string' } },
                ],
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                properties: {
                                    id: { type: 'string' },
                                    name: { type: 'string', example: 'payment_intent.succeeded' },
                                    account_id: { type: 'string' },
                                    created_at: { type: 'string', format: 'date-time' },
                                    data: {
                                        type: 'object',
                                        properties: { object: { type: 'object' } },
                                    },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: { description: 'Acknowledged' },
                    401: { description: 'Invalid signature' },
                    500: { description: 'Processing failed - Airwallex will retry' },
                },
            },
        },
        '/payments/{id}': {
            get: {
                tags: ['Payments'],
                summary: 'Get one payment with its full event timeline',
                description: 'Accepts a payment_intent_id, merchant_order_id or local _id.',
                security: [{ bearerAuth: [] }],
                parameters: [
                    { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
                ],
                responses: {
                    200: {
                        description: 'The payment',
                        content: {
                            'application/json': { schema: { $ref: '#/components/schemas/Payment' } },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    404: { description: 'Not found' },
                },
            },
        },
        '/payments/{id}/sync': {
            post: {
                tags: ['Payments'],
                summary: 'Re-read the intent from Airwallex and persist any change',
                security: [{ bearerAuth: [] }],
                parameters: [
                    { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
                ],
                responses: {
                    200: {
                        description: 'The refreshed payment',
                        content: {
                            'application/json': { schema: { $ref: '#/components/schemas/Payment' } },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    404: { description: 'Not found' },
                },
            },
        },
        '/payments/{id}/cancel': {
            post: {
                tags: ['Payments'],
                summary: 'Cancel a payment that has not completed',
                security: [{ bearerAuth: [] }],
                parameters: [
                    { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
                ],
                requestBody: {
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                properties: { reason: { type: 'string', example: 'requested_by_customer' } },
                            },
                        },
                    },
                },
                responses: {
                    200: {
                        description: 'The cancelled payment',
                        content: {
                            'application/json': { schema: { $ref: '#/components/schemas/Payment' } },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    404: { description: 'Not found' },
                    409: { description: 'Already in a terminal state' },
                },
            },
        },
        '/users': {
            get: {
                tags: ['Users'],
                summary: 'List users',
                security: [{ bearerAuth: [] }],
                parameters: [
                    { name: 'q', in: 'query', schema: { type: 'string' } },
                    {
                        name: 'status',
                        in: 'query',
                        schema: { type: 'string', enum: ['active', 'pending', 'revoked'] },
                    },
                    {
                        name: 'sort',
                        in: 'query',
                        schema: { type: 'string', enum: ['asc', 'desc'], default: 'desc' },
                    },
                    { name: 'limit', in: 'query', schema: { type: 'integer', default: 50 } },
                    { name: 'skip', in: 'query', schema: { type: 'integer', default: 0 } },
                ],
                responses: {
                    200: {
                        description: 'Paged list of users',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        items: {
                                            type: 'array',
                                            items: { $ref: '#/components/schemas/User' },
                                        },
                                        total: { type: 'integer' },
                                        limit: { type: 'integer' },
                                        skip: { type: 'integer' },
                                    },
                                },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                },
            },
            post: {
                tags: ['Users'],
                summary: 'Create an active user directly (with a password)',
                security: [{ bearerAuth: [] }],
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['email', 'first_name', 'last_name', 'password'],
                                properties: {
                                    email: { type: 'string', format: 'email' },
                                    first_name: { type: 'string' },
                                    last_name: { type: 'string' },
                                    password: { type: 'string', minLength: 8 },
                                },
                            },
                        },
                    },
                },
                responses: {
                    201: {
                        description: 'Created',
                        content: {
                            'application/json': {
                                schema: { $ref: '#/components/schemas/User' },
                            },
                        },
                    },
                    400: { $ref: '#/components/responses/BadRequest' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    409: { description: 'Email already in use' },
                },
            },
        },
        '/users/invite': {
            post: {
                tags: ['Users'],
                summary: 'Invite a user by email',
                security: [{ bearerAuth: [] }],
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['email', 'first_name', 'last_name'],
                                properties: {
                                    email: { type: 'string', format: 'email' },
                                    first_name: { type: 'string' },
                                    last_name: { type: 'string' },
                                },
                            },
                        },
                    },
                },
                responses: {
                    201: {
                        description: 'Invite created and emailed',
                        content: {
                            'application/json': {
                                schema: { $ref: '#/components/schemas/User' },
                            },
                        },
                    },
                    400: { $ref: '#/components/responses/BadRequest' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    409: { description: 'Email already in use' },
                },
            },
        },
        '/users/invite/preview': {
            get: {
                tags: ['Users'],
                summary: 'Look up an invite by token without consuming it',
                parameters: [
                    {
                        name: 'token',
                        in: 'query',
                        required: true,
                        schema: { type: 'string' },
                    },
                ],
                responses: {
                    200: {
                        description: 'Invite is valid',
                        content: {
                            'application/json': {
                                schema: {
                                    type: 'object',
                                    properties: {
                                        email: { type: 'string' },
                                        first_name: { type: 'string' },
                                        last_name: { type: 'string' },
                                    },
                                },
                            },
                        },
                    },
                    404: { description: 'Invalid invite link' },
                    410: { description: 'Invite expired' },
                },
            },
        },
        '/users/accept-invite': {
            post: {
                tags: ['Users'],
                summary: 'Accept an invite and set a password',
                requestBody: {
                    required: true,
                    content: {
                        'application/json': {
                            schema: {
                                type: 'object',
                                required: ['token', 'password'],
                                properties: {
                                    token: { type: 'string' },
                                    password: { type: 'string', minLength: 8 },
                                },
                            },
                        },
                    },
                },
                responses: {
                    200: { description: 'Invite accepted' },
                    400: { $ref: '#/components/responses/BadRequest' },
                    404: { description: 'Invalid invite link' },
                    410: { description: 'Invite expired' },
                },
            },
        },
        '/users/{id}': {
            get: {
                tags: ['Users'],
                summary: 'Get a user (own record only)',
                security: [{ bearerAuth: [] }],
                parameters: [
                    { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
                ],
                responses: {
                    200: {
                        description: 'The user',
                        content: {
                            'application/json': {
                                schema: { $ref: '#/components/schemas/User' },
                            },
                        },
                    },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    403: { description: 'Forbidden' },
                    404: { description: 'Not found' },
                },
            },
            delete: {
                tags: ['Users'],
                summary: 'Revoke a user’s access',
                security: [{ bearerAuth: [] }],
                parameters: [
                    { name: 'id', in: 'path', required: true, schema: { type: 'string' } },
                ],
                responses: {
                    200: {
                        description: 'The revoked user',
                        content: {
                            'application/json': {
                                schema: { $ref: '#/components/schemas/User' },
                            },
                        },
                    },
                    400: { description: 'Cannot revoke your own access' },
                    401: { $ref: '#/components/responses/Unauthorized' },
                    404: { description: 'Not found' },
                },
            },
        },
    },
};
